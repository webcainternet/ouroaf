						== Description ==

This extension provides you with functionality of Payu Payment Gateway for Opencart.

						== Installation ==

1) Copy all folders in upload directory to your root directory.

2) Extension is installed.

3) Go to Extensions - Payment->PayU. And you will find a button Enable/Edit.

4) In case you are still having doubt. I am at your service at support@evolvewebtech.com

5) Thank you.
