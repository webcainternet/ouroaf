<?php
$_['text_taxa_por_tipo_pagamento'] = 'Taxa/Desconto Por Tipo de Pagamento';
?>