<?php
#############################################################################

#############################################################################
// Heading
$_['heading_title']    = 'Product Password';
$_['enable_product_password']    = 'Enable Product Password Module';
$_['text_success']     = 'Success: You have modified module Product Password!';
$_['text_edit']    = 'Edit Product Password Module';

?>