<?php
// Heading 
$_['product_password_enter']  = "Please enter password to view this product ";
$_['product_password_error']  = "<span style='color:#ff0000'>Sorry, your password is not correct.</span>";
$_['product_password_submit']  = "Submit";
?>