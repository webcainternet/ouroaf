<?php
$_['text_payment_fee'] = 'Taxa';
$_['text_payment_discount'] = 'Desconto';
?>