<?php
$_['text_payment_fee'] = 'Payment Fee';
$_['text_payment_discount'] = 'Payment Discount';
?>