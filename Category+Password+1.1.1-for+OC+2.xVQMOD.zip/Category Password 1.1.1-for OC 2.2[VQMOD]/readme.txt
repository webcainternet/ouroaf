This module allows you to set password for each category.

Version 1.1.1
-Fixed session issue.
-Fixed mysql connect issue.

Feature:
You can set different password for each category.
If you set a password to a category , it wil require password to view.
Product under protected category can't be viewed or searched without entering password.
If one product is under multi categories, it will be protected only if you set password to all related categories.

Installation:
-Copy new folder to your site root
-In admin->Extensions->Modules, install "Category Password" module
-Click "Edit" and check "Enable Category Password" to enable it.
-Copy vqmod file "category_password.xml" to /vqmod/xml 

Note: 
You can define text in catalog/language/english/module/category_password.php
If you use other languages, please copy and edit file to  
/catalog/language/[Your Language]/module/category_password.php
Please change [Your Language] to your language name accordingly. 

Questions/support: yolanda_txw@hotmail.com



