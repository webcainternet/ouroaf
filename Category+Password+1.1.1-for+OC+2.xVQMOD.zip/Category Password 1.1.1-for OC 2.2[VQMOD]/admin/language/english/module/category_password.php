<?php
#############################################################################

#############################################################################
// Heading
$_['heading_title']    = 'Category Password';
$_['enable_category_password']    = 'Enable Category Password Module';
$_['text_success']     = 'Success: You have modified module Category Password!';
$_['text_module']      = 'Modules';
$_['text_edit']        = 'Edit Category Password Module';

?>