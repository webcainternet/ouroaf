<?php
// Heading 
$_['category_password_enter']  = "Please enter password to view this category ";
$_['category_password_error']  = "<span style='color:#ff0000'>Sorry, your password is not correct.</span>";
$_['category_password_submit']  = "Submit";
?>