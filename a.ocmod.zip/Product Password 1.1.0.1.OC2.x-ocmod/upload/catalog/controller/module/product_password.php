<?php

class ControllerModuleProductpassword extends Controller {
	protected $data;
	protected function index($module) {
	}
}


?>